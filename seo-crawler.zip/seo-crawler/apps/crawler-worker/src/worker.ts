// Advanced SEO Intelligence & Technical Crawler — Crawl Worker
// Copyright (c) 2026 Bibas Gautam — MIT License
//
// Consumes crawl jobs from a BullMQ queue, fetches pages with Playwright,
// parses them with Cheerio, and extracts SEO signals (metadata, canonical
// tags, structured data, links, Core Web Vitals hooks).

import { Worker, type Job } from "bullmq";
import { chromium } from "playwright";
import * as cheerio from "cheerio";

const connection = { url: process.env.REDIS_URL || "redis://localhost:6379" };

interface CrawlJobData {
  url: string;
  projectId: string;
}

async function crawlPage(url: string) {
  const browser = await chromium.launch();
  const page = await browser.newPage({
    userAgent: process.env.CRAWLER_USER_AGENT || "SEOIntelBot/1.0",
  });

  const response = await page.goto(url, { waitUntil: "networkidle" });
  const html = await page.content();
  await browser.close();

  const $ = cheerio.load(html);

  return {
    url,
    statusCode: response?.status() ?? null,
    title: $("title").first().text().trim(),
    metaDescription: $('meta[name="description"]').attr("content") ?? null,
    canonical: $('link[rel="canonical"]').attr("href") ?? null,
    h1Count: $("h1").length,
    structuredData: $('script[type="application/ld+json"]')
      .map((_, el) => $(el).text())
      .get(),
    links: $("a[href]")
      .map((_, el) => $(el).attr("href"))
      .get(),
  };
}

new Worker<CrawlJobData>(
  "crawl-queue",
  async (job: Job<CrawlJobData>) => {
    console.log(`[crawler-worker] crawling ${job.data.url}`);
    const result = await crawlPage(job.data.url);
    // TODO: persist result to PostgreSQL + index in Elasticsearch
    return result;
  },
  {
    connection,
    concurrency: process.env.CRAWLER_CONCURRENCY
      ? Number(process.env.CRAWLER_CONCURRENCY)
      : 5,
  }
);

console.log("[crawler-worker] listening for crawl jobs...");
