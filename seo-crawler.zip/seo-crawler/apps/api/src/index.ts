// Advanced SEO Intelligence & Technical Crawler — API Gateway
// Copyright (c) 2026 Bibas Gautam — MIT License

import express from "express";

const app = express();
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "api" });
});

// TODO: mount routes for projects, crawls, reports, structured-data checks,
// Core Web Vitals ingestion, etc.

const PORT = process.env.API_PORT ? Number(process.env.API_PORT) : 4000;
app.listen(PORT, () => {
  console.log(`[api] listening on port ${PORT}`);
});
